# -*- coding: utf-8 -*-
import logging

from datetime import timedelta
from importlib.metadata import requires
from platform import platform, release

from odoo import models, fields, api
from odoo.exceptions import ValidationError
from odoo.exceptions import UserError
from odoo.tools.translate import _

logger = logging.getLogger(__name__)


class LibraryGame(models.Model):
    _name = 'library.game'
    _description = 'Games Library'

    name = fields.Char('Title', required=True)
    entry_date = fields.Date('Entry Date')
    dev_name = fields.Char('Name Developers')
    platform = fields.Char('Platform', required=True)
    original_cost = fields.Float('Original Cost')
    actual_cost = fields.Float('Actual Cost', required=True)
    state = fields.Char('State', required=True)
    rented_name = fields.Char('Name of who rented the game')
    rented_id = fields.Char('id of the client')
    category_id = fields.Many2one('library.game.category', string='Category')

    state = fields.Selection([
        ('draft', 'Unavailable'),
        ('available', 'Available'),
        ('borrowed', 'Borrowed'),      
        ('lost', 'Lost'),
        ('selled', 'Selled')],
        'State', default="draft")
   
    @api.model
    def is_allowed_transition(self, old_state, new_state):
        allowed = [('draft', 'available'),
                   ('available', 'borrowed'),
                   ('borrowed', 'available'),
                   ('available', 'lost'),
                   ('borrowed', 'lost'),
                   ('lost', 'available')
                   ('available', 'sold')]
        return (old_state, new_state) in allowed

    def change_state(self, new_state):
        for game in self:
            if game.is_allowed_transition(game.state, new_state):
                game.state = new_state
            else:
                message = _('Moving from %s to %s is not allowd') % (game.state, new_state)
                raise UserError(message)

    def make_available(self):
        self.change_state('available')

    def make_borrowed(self):
        self.change_state('borrowed')

    def make_lost(self):
        self.change_state('lost')

    def make_sold(self):
        self.change_state('sold')        

def create_categories(self):
        categ1 = {
            'name': 'Child category 1',
            'description': 'Description for child 1'
        }
        categ2 = {
            'name': 'Child category 2',
            'description': 'Description for child 2'
        }
        parent_category_val = {
            'name': 'Parent category',
            'description': 'Description for parent category',
            'child_ids': [
                (0, 0, categ1),
                (0, 0, categ2),
            ]
        }
        # Total 3 records (1 parent and 2 child) will be craeted in library.game.category model
        record = self.env['library.game.category'].create(parent_category_val)
        return True   

def change_entry_date(self):
        self.ensure_one()
        self.date_release = fields.Date.today()    